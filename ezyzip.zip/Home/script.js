gsap.from(".box", {
    duration: 2,
    scale: 0.9, 
    opacity: 0, 
    delay: 0.5, 
    stagger: 0.9,
    ease: "elastic", 
    force3D: true
  });
  
  document.querySelectorAll(".box").forEach(function(box) {
    box.addEventListener("click", function() {
      gsap.to(".box", {
        duration: 0.5, 
        opacity: 0, 
        y: -100, 
        stagger: 0.2,
        ease: "back.in"
      });
    });
  });

function btnClicked(){
  window.location.replace("review.html");
}